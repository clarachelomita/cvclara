<?php
require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM cv_clara");
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cv_clara</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<div class="header"> 
<div class="gambar"> <img src="logo.png" alt="ini gambar saya">
</div>
<?php
    foreach ($cari as $cari2):
    ?>
<h1>clara</h1>
<h3>girlfriend vtyaadidprtma </h3>
<?php
    endforeach;
    ?>
</div>
<div class="main">
    <div class="left">
      <h2>Informasi identitas</h2>
      <p><strong> Nama </strong>CLARA CHELOMITA</p>
      <p><strong> Alamat </strong>Kasang pudak </p>
      <p><strong> No_hp </strong>083857769225</p>
      <p><strong> Skil </strong>Bermain voly</p>
      <h2>Pendidikan</h2>
      <p><strong> Sekolah Dasar </strong>SDN 61 Kasang Pudak</p>
      <p><strong> Sekolah Lanjutan Tingkat Pertama </strong>SMP 8 Muaro Jambi</p>
      <p><strong> Sekolah Menengah Kejuruan </strong>SMK 6 Kota Jambi</p>
    </div>
    <div class="right">
        <h2>Pekerjaan</h2>
        <p><strong> Dikorea </strong>Manajer Jisung</p>
        <h2>Kepribadian</h2>
        <p><strong> Sifat </strong>Saya</p>
        <li>Lemah lembut</li>
        <li>Tidak suka marah marah</li>
        <li>Rajin membantu</li>
    </div>
</div>
</div>
</body>
</html>