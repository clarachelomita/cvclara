<?php
require 'function.php';
$hapus = $_GET ["no"];



if (hapus($hapus)>0){
    echo "<script>
    alert ('Data Berhasil Dihapus');
    document.location.href='index.php';
    </script>";
} else{
    echo "<script>
    alert ('Data Gagal Dihapus');
    document.location.href='index.php';
    </script>";
}
?>