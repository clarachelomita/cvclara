<?php
$database= mysqli_connect('localhost','root','','clara');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $umur = $_POST ["umur"];
    $kelas = $_POST ["kelas"];
    $no_hp = $_POST ["no_hp"];
    $tanggal_lahir = $_POST ["tanggal_lahir"];
    $pengalaman = $_POST ["pengalaman"];
    $skill = $_POST ["skill"];
    $pendidikan = $_POST ["pendidikan"];
    $hobi = $_POST ["hobi"];
    $tambah = "INSERT INTO cv_clara VALUE
    ('','$nama','$umur','$kelas','$no_hp','$tanggal_lahir','$pengalaman','$skill','$pendidikan','$hobi')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM cv_clara where no=$hapus");
    return mysqli_affected_rows($database);
}


?>