<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}

require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM cv_clara");
if (isset ($_POST["tombol"])){
    $Pencarian= $_POST ["pencarian"];
    $datayangdicari= "SELECT *FROM clara WHERE
     nama like '%$Pencarian%' or
   kelas like '%$Pencarian%'or
    umur like '%$Pencarian%' or
     no_hp like '%$Pencarian%' or
      tanggal_lahir like '%$Pencarian%' or
       pengalaman like '%$Pencarian%' or
       skill like '%$Pencarian%' or
       pendidikan like '%$Pencarian%' or
       hobi like '%$Pencarian%";
    $cari= mysqli_query ($database,$datayangdicari);
} else {
    $cari= mysqli_query ($database,'SELECT*FROM cv_clara');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="logo">
    </div>
    <div id="header-title">
<a href="index.php">clara</a>
    </div>
    </div>
    <div class="menu">
        <ul class="menu-item">
        <li class="menu-item"><a href="index.php">Data</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Data</a></li>
        <li class="menu-item"><a href="tentang.php">Tentang Clara</a></li>
        <li class="menu-item"><a href="login.php">Keluar</a></li>
        </ul>
    </div>
    <div class="konten">
<h1>CLARA CHELOMITA</h1> 
<p>CLARA CHELOMITA adalah salah satu siswi SMK NEGERI 6 KOTA JAMBI</p>

</div>
</body>
<body>
       <h1>Hak Cipta 2025 . Pengembangan Perangkat Lunak dan Gim</h1>
</div>

</html>