-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2025 at 04:33 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clara`
--

-- --------------------------------------------------------

--
-- Table structure for table `cv clara`
--

CREATE TABLE `cv clara` (
  `no` int(11) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  `kelas` varchar(100) NOT NULL,
  `umur` varchar(100) NOT NULL,
  `no_hp` varchar(100) NOT NULL,
  `tanggal_lahir` varchar(100) NOT NULL,
  `pengalaman` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cv clara`
--

INSERT INTO `cv clara` (`no`, `nama`, `kelas`, `umur`, `no_hp`, `tanggal_lahir`, `pengalaman`) VALUES
(NULL, 'CLARA CHELOMITA', 'XI PPLG 2', '17 TAHUN', '083857769225', '03-03-2008', '-Lomba voly antar sekolah\r\n-kegiatan pramuka');

-- --------------------------------------------------------

--
-- Table structure for table `cv_clara`
--

CREATE TABLE `cv_clara` (
  `no` int(11) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  `kelas` varchar(100) NOT NULL,
  `umur` varchar(100) NOT NULL,
  `no_hp` varchar(100) NOT NULL,
  `tanggal_lahir` varchar(100) NOT NULL,
  `pengalaman` varchar(1000) NOT NULL,
  `skill` varchar(100) NOT NULL,
  `pendidikan` varchar(100) NOT NULL,
  `hobi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cv_clara`
--

INSERT INTO `cv_clara` (`no`, `nama`, `kelas`, `umur`, `no_hp`, `tanggal_lahir`, `pengalaman`, `skill`, `pendidikan`, `hobi`) VALUES
(NULL, 'CLARA CHELOMITA', 'XI PLLG2', '17 TAHUN', '083857769225', '03-03-2008', '-LOMBA VOLY ANTAR SEKOLAH\r\n-ESKUL PRAMUKA', '', '', ''),
(0, 'RISKA', '5sd', '6thun', '3435465876997', '23456', 'TIDUR', 'TIDUR', 'blabla', 'tidur');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('clara', 'clara123'),
('clara', 'clara123'),
('selo', 'selo123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
